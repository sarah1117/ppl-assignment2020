class Shape: 
    
     # private members 
     __name = None
     __colour = None
     __trait = None
  
     # constructor 
     def __init__(self, name, colour, trait):   
          self.__name = name 
          self.__colour = colour 
          self.__trait = trait
  
     # private member function   
     def __displayDetails(self): 
            
           # accessing private data members 
           print("Name: ", self.__name) 
           print("Colour: ", self.__colour) 
           print("Trait: ", self.__trait) 
     
     # public member function 
     def accessPrivateFunction(self):  
             
           # accesing private member function 
           self.__displayDetails()   
  
# creating object     
obj = Shape("Octagon", "Blue", "Has 8 sides") 
  
# calling public member function of the class 
obj.accessPrivateFunction() 
