class Pigeon: 
    
     # private members 
     __name = None
     __breed = None
     __trait = None
  
     # constructor 
     def __init__(self, name, breed, trait):   
          self.__name = name 
          self.__breed = breed 
          self.__trait = trait
  
     # private member function   
     def __displayDetails(self): 
            
           # accessing private data members 
           print("Name: ", self.__name) 
           print("Breed: ", self.__breed) 
           print("Trait: ", self.__trait) 
     
     # public member function 
     def accessPrivateFunction(self):  
             
           # accesing private member function 
           self.__displayDetails()   
  
# creating object     
obj = Pigeon("Laila", "Ice pigeon", "Cooing") 
  
# calling public member function of the class 
obj.accessPrivateFunction() 
