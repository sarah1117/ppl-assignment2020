class Cat: 
       
     # constructor 
     def __init__(self, name, breed, trait): 
            
           # public data mambers  
           self.catName = name 
           self.catBreed = breed
           self.catTrait = trait
  
     # public memeber function       
     def displayBreed(self): 
            
           # accessing public data member 
           print("Breed: ", self.catBreed) 
     
     # public memeber function       
     def displayTrait(self): 
            
           # accessing public data member 
           print("Trait: ", self.catTrait)      
        
  
# creating object of the class 
obj = Cat("Mau", "Bombay", "Meowing") 
  
# accessing public data member 
print("Name: ", obj.catName) 
  
# calling public member function of the class 
obj.displayBreed() 
obj.displayTrait()
