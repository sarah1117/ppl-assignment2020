class Shape: 
       
     # constructor 
     def __init__(self, name, colour, trait): 
            
           # public data mambers  
           self.shapeName = name 
           self.shapeColour = colour
           self.shapeTrait = trait
  
     # public memeber function       
     def displayColour(self): 
            
           # accessing public data member 
           print("Colour: ", self.shapeColour) 
     
     # public memeber function       
     def displayTrait(self): 
            
           # accessing public data member 
           print("Trait: ", self.shapeTrait)      
        
  
# creating object of the class 
obj = Shape("Square", "Yellow", "All sides are Equal") 
  
# accessing public data member 
print("Name: ", obj.shapeName) 
  
# calling public member function of the class 
obj.displayColour() 
obj.displayTrait()
