class Dog: 
       
     # constructor 
     def __init__(self, name, breed, trait): 
            
           # public data mambers  
           self.dogName = name 
           self.dogBreed = breed
           self.dogTrait = trait
  
     # public memeber function       
     def displayBreed(self): 
            
           # accessing public data member 
           print("Breed: ", self.dogBreed) 
     
     # public memeber function       
     def displayTrait(self): 
            
           # accessing public data member 
           print("Trait: ", self.dogTrait)      
        
  
# creating object of the class 
obj = Dog("Fido", "Golden Retriever", "Barking") 
  
# accessing public data member 
print("Name: ", obj.dogName) 
  
# calling public member function of the class 
obj.displayBreed() 
obj.displayTrait()
